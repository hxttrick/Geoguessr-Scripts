1. Host this folder using vs code Live Preview or any other method.
2. Change the LOCALHOST_PORT constant inside userscript.js to whatever port you're hosting it on. (defaults 5500)
3. With the provided userscript.js (using tampermonkey or any other alternative), go to a clubs page as shown in the image below, click the club icon, and it will open index.html with the correct parameters to display your club icon!
![Club Page Example](https://i.imgur.com/5V8l2Q4.png)